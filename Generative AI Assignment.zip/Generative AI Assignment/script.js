
// Load CSV
d3.csv("maricopa_heat_deaths_2025.csv").then(function(data) {

    console.log("Loaded data:", data);

    // Count deaths by race
    let counts = {};

    data.forEach(d => {
        let race = d.race;

        if (!counts[race]) {
            counts[race] = 0;
        }

        counts[race]++;
    });

    // Convert to array
    let dataset = Object.entries(counts).map(d => ({
        race: d[0],
        count: d[1]
    }));

    // Sort highest → lowest (important for clarity)
    dataset.sort((a, b) => b.count - a.count);

    // Chart dimensions
    let width = 750;
    let height = 450;
    let margin = { top: 30, right: 20, bottom: 120, left: 60 };

    let svg = d3.select("#chart")
        .append("svg")
        .attr("width", width)
        .attr("height", height);

    // Scales
    let x = d3.scaleBand()
        .domain(dataset.map(d => d.race))
        .range([margin.left, width - margin.right])
        .padding(0.25);

    let y = d3.scaleLinear()
        .domain([0, d3.max(dataset, d => d.count)])
        .nice()
        .range([height - margin.bottom, margin.top]);

    // Color palette
    let color = d3.scaleOrdinal()
        .domain(dataset.map(d => d.race))
        .range(["#4E79A7", "#F28E2B", "#E15759", "#76B7B2", "#59A14F", "#EDC948"]);

    // Draw bars
    svg.selectAll(".bar")
        .data(dataset)
        .enter()
        .append("rect")
        .attr("class", "bar")
        .attr("x", d => x(d.race))
        .attr("y", d => y(d.count))
        .attr("width", x.bandwidth())
        .attr("height", d => height - margin.bottom - y(d.count))
        .attr("fill", d => color(d.race));

    // Value labels
    svg.selectAll(".label")
        .data(dataset)
        .enter()
        .append("text")
        .text(d => d.count)
        .attr("x", d => x(d.race) + x.bandwidth() / 2)
        .attr("y", d => y(d.count) - 6)
        .attr("text-anchor", "middle")
        .style("font-size", "12px")
        .style("fill", "#333");

    // X-axis (rotated to prevent overlap)
    let xAxis = svg.append("g")
        .attr("transform", `translate(0,${height - margin.bottom})`)
        .call(d3.axisBottom(x));

    xAxis.selectAll("text")
        .style("text-anchor", "end")
        .attr("dx", "-0.8em")
        .attr("dy", "0.15em")
        .attr("transform", "rotate(-35)");

    // Y-axis
    svg.append("g")
        .attr("transform", `translate(${margin.left},0)`)
        .call(d3.axisLeft(y));

});